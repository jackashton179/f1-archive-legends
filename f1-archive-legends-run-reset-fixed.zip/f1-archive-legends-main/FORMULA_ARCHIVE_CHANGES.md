# Formula Archive changes

## Run navigation/state fix

- Added a central `resetCurrentRun()` action in `src/game/store.tsx`.
- `resetCurrentRun()` clears only temporary run state. It does not alter localStorage/save data.
- Homepage `Start a season` now resets any abandoned previous run before entering `/play`.
- The Play header Home action now displays a confirmation dialog.
- Confirming Home resets the run and returns to `/`.
- Cancelling the dialog leaves the player exactly where they were.
- Post-season `Roll again` now appears immediately after the final classification summary, before the full standings.
- Post-season Home uses the same confirmation/reset flow.
- `GameButton` now forwards its ref so it works correctly as a Radix AlertDialog trigger.

## Persistence intentionally preserved

The reset does NOT change:
- Formula Archive collection
- shiny collection
- achievements
- career stats
- run history
